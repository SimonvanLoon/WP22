<footer>
    <p>Simon van Loon, s3515710</p>
</footer>
</body>
</html>